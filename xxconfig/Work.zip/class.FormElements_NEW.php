<?php

class FormElements {
    
    public function __construct($form_name) {
        
	$this->form_name         = $form_name;
	$this->forms_path        = FORMS_PATH . "/" . $form_name;
        $this->config_json_array = $this->_parse_json_file();
		
    }
    
    private function _parse_json_file() {
        
        $json_file = file_get_contents(FORMS_PATH . "/" . $this->form_name . "/config.json");
        if(!$json_array = json_decode($json_file,true)) {
            
            echo trigger_error("error:there is a syntax in the json file, please correct and try again");
            
        }
        
        return $json_array;
        
    }
	
    public function create_element($section, $div_width = '') {

        $element_type = $this->config_json_array[$section][0]["element_type"];
        
        switch($element_type) {

            case "text" :

                $this->create_input_element($section);

                break;

            case "select" : 

                $this->_create_select($section);

                break;

            case "text-area" : 

                $this->_create_text_area_element($section);

                break;

            case "file" : 

                $this->_create_upload_element($section);

                break;

            case "submit" : 
                
                $this->_create_button($section);

                break;

            case "radio" : 
            case "checkbox" :
                
                $this->_create_chk_rad_element($section);

                break;
        }

    }

    private function _array_to_object($array) {
        
        if (!is_array($array)) {
            
            return $array;
        }

        $object = new stdClass();
        
        if (is_array($array) && count($array) > 0) {
            
            foreach ($array as $name => $value) {
                
                $name = strtolower(trim($name));
                
                if (!empty($name)) {
                    
                    $object->$name = $this->_array_to_object($value);
                    //echo $name . ' - ' . $value . '<br />';
                }
            }
            
            return $object;
        }
        else {
            return FALSE;
        }
    }

    public function create_input_element($section) {
        
        $json_elm_settings = $this->_json_form_element_settings($section);
        $onclick = isset($json_elm_settings['onclick']) && $json_elm_settings['onclick'] != '' ? $onclick = $json_elm_settings['onclick'] : $onclick = '' ;
        
        ?>
         <div class="inner_container">
            <div class="inner_box">
                <div class="html_title"><?php echo $json_elm_settings['html_title'] ?></div>
                <div class="element_spacing, grey_bg"><input type="<?php echo $json_elm_settings['element_type'] ?>" size="<?php echo $json_elm_settings['size'] ?>" name="<?php echo $json_elm_settings['element_name'] ?>" id="<?php echo $json_elm_settings['element_name'] ?>" value="" class="<?php echo $json_elm_settings['css_class'] ?>" <?php $onclick != '' ? print "onclick=\"$onclick\""  : print '' ; ?> /></div>
            </div>
        <?php 
        if(isset($this->config_json_array[$section][0]["text_right"]) && $this->config_json_array[$section][0]["text_right"] != '') {
        ?>
            <div>&nbsp;<?php echo $this->config_json_array[$section][0]["text_right"] ?></div>
        <?php
        }
        ?>
         </div>
        <?php  
    }
    
    public function create_sub_title($sub_title) {
        ?>
        <div class="sub_title"><?php echo $sub_title ?></div>
        <div class="hr_spacing">
            <hr />
        </div>
        <?php
    }
    
    public function create_section($section_title) {
        ?>
        <div class="section_title_container">
            <div class="section_title"><?php echo $section_title ?></div>
            <div class="hr_spacing">
                <hr />
            </div>
            <?php 
            $this->create_element("pos_width");
            $this->create_element("pos_depth");
            $this->create_element("pos_other");
            ?>
        </div>
        <?php
    }
    
    private function _json_form_element_settings($section) {
        
        $element_settings = array();
        
        $element_settings['element_name']     = $this->config_json_array[$section][0]['element_name'] . "[]";
        $element_settings['element_type']     = $this->config_json_array[$section][0]['element_type'];
        $element_settings['html_title']       = $this->config_json_array[$section][0]['html_title'];
        $element_settings['element_required'] = $this->config_json_array[$section][0]['required'];
	$element_settings['css_class']        = $this->config_json_array[$section][0]['css_class'];
	$element_settings['size']             = $this->config_json_array[$section][0]['size'];
	$element_settings['xml_tag']          = $this->config_json_array[$section][0]['xml_tag'];
        //$element_settings['list_items']       = $this->config_json_array[$section][0]['list_item'];
        $element_settings['format_settings']  = $this->config_json_array[$section][0]['format_settings'][0];
        $element_settings['element_id']       = $this->config_json_array[$section][0]['id'];
        
        isset($this->config_json_array[$section][0]['onclick']) && $this->config_json_array[$section][0]['onclick'] != '' ? $element_settings['onclick'] = $this->config_json_array[$section][0]['onclick'] : $element_settings['onclick'] = '' ;
        
        return $element_settings;
        
    }
    
    private function _create_chk_rad_element($section) {
        
        $json_elm_settings = $this->_json_form_element_settings($section);
                
        ?>
        <div class="inner_container">
            <div class="inner_box" style="width:<?php echo $json_elm_settings['format_settings']['div_width'] ?>;">
                <div style="padding:3px 0px 10px 0px;">
                    <table cellpadding="0" cellspacing="0" border="0">
                        <tr>
                            <td><div class="html_title"><?php echo $json_elm_settings['html_title']  ?></div></td>
                        </tr>
                        <?php
                        
                        $i = 0;
                        foreach($this->config_json_array[$section][0]['list_item'][0] as $key => $value) {

                            $element_id = $key;

                            if(strpos($key,'->')) {

                                $js = explode('->', $key);
                                $element_id     = trim($js[0]);
                                $set_javascript = trim($js[1]);

                            }

                            if(isset($json_elm_settings['format_settings']['elements_per_line']) && $json_elm_settings['format_settings']['elements_per_line'] != 'nan') {

                                if(!$i % $json_elm_settings['format_settings']['elements_per_line']) {
                                    ?>
                                    <tr>
                                    <?php
                                }
                                ?>
                                <td>
                                    <input type="<?php echo $json_elm_settings['element_type'] ?>" name="<?php echo $json_elm_settings['element_name'] ?>" id="<?php echo $json_elm_settings['element_id'] ?>" value="<?php echo $json_elm_settings['element_id'] ?>" />&nbsp;&nbsp;<?php echo $value ?>&nbsp;&nbsp;&nbsp;
                                </td>
                            <?php
                                if($i % $json_elm_settings['format_settings']['elements_per_line']) {
                                    ?>
                                    </tr>
                                    <?php
                                }
                            } else {

                                if($i == 0) {
                                    ?>
                                    <tr>
                                    <?php
                                }

                            ?>
                                <td>
                                    <input type="<?php echo $json_elm_settings['element_type'] ?>" name="<?php echo $json_elm_settings['element_name'] ?>" id="<?php echo $json_elm_settings['element_id'] ?>" value="<?php echo $json_elm_settings['element_id'] ?>" />&nbsp;&nbsp;<?php echo $value ?>&nbsp;&nbsp;&nbsp;
                                </td>
                            <?php
                                if($i == count($this->config_json_array[$section][0]['list_item'][0]) - 1) {
                                    ?>
                                    </tr>
                                    <?php
                                }
                            }
                            $i++;
                        }
                        ?>
                    </table>                    
                </div>
            </div>
            <?php 
            if($json_elm_settings['format_settings']['div_width'] == '100%') {
                ?>
                <br style="clear:both" />
                <?php
            }
            ?>
        </div>
        <?php
        $set_javascript = '';
    }

    private function _create_select($section) {
        
        $json_elm_settings = $this->_json_form_element_settings($section);
        
        //** path to the text file containing the publication names        
        $form_select_list = FORMS_PATH . "/select_lists/" . $this->config_json_array[$section][0]['data_file'];
        
        ?>
        <div class="inner_container">
            <div class="inner_box">
                <div class="html_title"><?php echo $json_elm_settings['html_title'] ?></div>
                <div class="element_spacing">
                    <select name="<?php print $json_elm_settings['element_name'] ?>" id="<?php print $$json_elm_settings['element_name'] ?>">
                        <option value=""> -- select -- </option>
                        <?php
                        if($file_handle = fopen($form_select_list,"r")) {

                            while( !feof($file_handle) ) {
                                
                                $line = fgets($file_handle);
                                ?>
                                    <option value="<?php print trim(str_replace(' ','_',$line)) ?>"><?php echo trim($line) ?></option>
                                    <?php 
                            } 

                        } else {

                            echo 'file does not exist';

                        }
                ?>
                    </select>
                </div>
            </div>
        </div>
        <?php
    }
	
    private function _create_text_area_element($section) {
        
       $json_elm_settings = $this->_json_form_element_settings($section);
       
    ?>   
         <div class="inner_container">
            <div class="inner_box">
                <div class="html_title"><?php echo $json_elm_settings['html_title'] ?></div>
                <div class="element_spacing">
                    <span><textarea name="<?php echo $json_elm_settings['element_name'] ?>" id="<?php echo $json_elm_settings['element_name'] ?>" rows="<?php echo $this->config_json_array[$section][0]['rows'] ?>" cols="<?php echo $this->config_json_array[$section][0]['cols'] ?>" class="<?php echo $json_elm_settings['css_class'] ?>"></textarea></span>
                </div>
            </div>
        </div>
		<!--<input type="hidden" name="<?php echo $section ?>_name" value="<?php echo $section ?>_value" />-->
    <?php  
    }
	
    private function _create_upload_element($section, $javascript = '') {
	
	$element_settings = $this->_array_to_object($this->config_json_array[$section][0]);
        
	?>
        <div class="inner_container">
            <div class="inner_box">
                <div class="html_title"><?php echo $json_elm_settings['html_title'] ?></div>
                <div class="element_spacing">
                    <span><input type="file" name="<?php echo $json_elm_settings['element_name'] ?>" id="<?php echo $json_elm_settings['element_name'] ?>" class="<?php echo $json_elm_settings['css_class'] ?>" /></span>
                </div>      
            </div>
        </div>
    <?php
    }

    public function get_sub_dirs() {
        ?>
        <a href="<?php echo FORMS_URL ?>/links.php?form_name=default\">JSON files</a> >
        <?php
        foreach(glob(FORMS_PATH . "/", GLOB_ONLYDIR) as $image) {
            $form_name = substr(strrchr($image, '/'), 1, strlen(strrchr($image, '\/')));
            if($form_name != 'select_lists') {
                ?>
                <a href="<?php echo FORMS_URL ?>/<?php echo $form_name ?>/index.php"><?php echo $form_name ?></a> > 
                <?php
            }
        }
    }
	
    private function _create_button($section, $javascript = '') {
	
        $element_type     = $this->config_json_array[$section][0]["element_type"];
        $html_title       = $this->config_json_array[$section][0]["html_title"];
	$css_class        = $this->config_json_array[$section][0]["css_class"];
	?>
        <div class="row">
            <div class="buttonContainer">
                <span class="buttonSpacing" style="padding-left:278px;"><input type="<?php echo $element_type ?>" value="<?php echo $html_title ?>" class="<?php echo $css_class ?>" /></span>
            </div>
        </div>
        <div style="padding:0px 0px 20px 0px;"></div>
	<?php
    }
	
}

?>
<?php
require("../../globals.php");

$form_name = substr(strrchr(getcwd(), '\/'), 1, strlen(strrchr(getcwd(), '\/')));

include(INCLUDES_PATH . "/site_header.php");

?>
 <script type="text/javascript">
    
    function show_div() {
        
        $("#press_advertisement_div").hide();
        $("#flyer_width_div").hide();
        $("#flyer_height_div").hide();
        $("#pos_width_div").hide();
        $("#pos_height_div").hide();
        
        for (i = 0; i < arguments.length; i++) {
            
            $(arguments[i]).show();        
            
        }
        
	<?php 
	if(isset($_REQUEST['adnumber'])) {
	?>
            $("#press_advertisement_div").show();
            $("#flyer_width_div").show();
            $("#flyer_height_div").show();
            $("#pos_width_div").show();
            $("#pos_height_div").show();
					
	<?php
	}
	?>
    }
    
    $(document).ready(function() {
        
        <?php
        if(!isset($_REQUEST['adnumber'])) {
        ?>
            $("#type_of_request_print_div").hide();
            $("#press_ad_div").hide();
            $("#flyer_width_div").hide();
            $("#flyer_height_div").hide();
            $("#pos_width_div").hide();
            $("#pos_height_div").hide();
        <?php
        }
        ?>
    });

 </script>
<!--<a href="<?php echo FORMS_URL  ?>/digital/index.php">JSON Files</a>-->
<form id="<?php echo $form_name ?>" name="<?php echo $form_name ?>" action="<?php echo ROOT_URL ?>/forms/process.php" method="post" enctype="multipart/form-data">
	<input type="hidden" name="form_name" id="form_name" value="<?php echo $form_name ?>" />
	<?php
	if (isset($_REQUEST["adnumber"])) {
		?>
		<input type="hidden" name="adnumber" value="<?php echo $_REQUEST["adnumber"]; ?>" />
		
		<div class="row">          
			<div class="leftCol" style="padding:0px 8px 5px 0px;">Adnumber</div>
			<div class="rightCol" style="font-weight:bold;"><?php echo $_REQUEST['adnumber'] ?></div>                
		</div>  
		<?php
	}
	?>
        <style type="text/css">
            .form_title { width:720px; margin: auto; border: 0px solid #000; padding: 20px 0px 5px 0px; font-size: 16px; text-transform: uppercase; }
            .sub_title { padding: 10px 0px 0px 0px; font-size: 16px; }
            .section_title { padding: 10px 0px 0px 0px; font-size: 16px }
            .section_title_container { padding: 10px 0px 0px 0px; font-size: 14px; width:98%; margin: auto; background-color: #f0f0f0; }
            .outer_container { border:0px solid #000; width:700px; margin: auto}
            .inner_container { border:0px solid #000; width:700px; margin: auto; background:rgba(255,255,255,0.5); }
            .inner_box { display: inline-block; border: 0px solid #000; position: relative; margin: 1%; width:49%;  float:left; margin:0; background:#7f7f7f;; background:rgba(255,255,255,0.5); } 
            .html_title { padding:0px 0px 3px 0px; }
            .element_spacing { padding:0px 0px 10px 0px; }
            .hr_spacing { padding: 0px 0px 10px 0px; }
            .grey_bg { background-color: #f0f0f0; }
            hr { border-color: #0082DA ; }
        </style>        
        <div class="form_title">Marketing</div>
        <div class="outer_container">
            <?php 
            $form_elements->create_sub_title("Your Details");
            $form_elements->create_element("first_name");
            $form_elements->create_element("last_name");
            $form_elements->create_element("phone");
            $form_elements->create_element("email");
            $form_elements->create_element("state");
            ?>
            <br style="clear:both" />
            <?php
            $form_elements->create_sub_title("Project Details");
            ?>
        </div>
        <div class="outer_container">
            <?php
            $form_elements->create_element("type_of_work");
            $form_elements->create_element("project_name");
            ?>
            <br style="clear:both" />
            <?php
            $form_elements->create_element("platform");
            $form_elements->create_element("addition_to_recent_request");
            $form_elements->create_element("due_date");
            ?>
            <br style="clear:both" />
            <?php 
            $form_elements->create_sub_title("Print");
            $form_elements->create_element("type_of_request_print");
            ?>
            <br style="clear:both" />
            <?php
            $form_elements->create_element("publication");
            ?>
            <br style="clear:both" />
            <?php
            $form_elements->create_element("press_ad");
            ?>
            <br style="clear:both" />
            <?php
            $form_elements->create_section("POS (mm width x depth)");
            ?>
            <br style="clear:both" />
            <?php
            $form_elements->create_element("bleed");
            ?>
            <br style="clear:both" />
        </div>
        <div class="outer_container">
            <?php 
            $form_elements->create_sub_title("Creative Details");
            ?>
            <div class="inner_container" style="width: 100%;border:0px solid #000;">
            <?php
            $form_elements->create_element("whats_required");
            ?>
            </div>
        </div><br style="clear:both" />
        <div class="outer_container">
            <?php
            
            ?>
        </div>
        <?php  
        
	/***
	$form_elements->create_element("project_name");
	$form_elements->create_element("state");
	$form_elements->create_element("publication");
	$form_elements->create_element("press_date");
	$form_elements->create_element("publication_date");
	$form_elements->create_element("platform");
	$form_elements->create_element("type_of_request_print");
	$form_elements->create_element("press_ad");
	$form_elements->create_element("flyer_width");
	$form_elements->create_element("flyer_height");
	$form_elements->create_element("pos_width");
	$form_elements->create_element("pos_height");
	$form_elements->create_element("colour");
	$form_elements->create_element("bleed");
	$form_elements->create_element("additional_comments");
	$form_elements->create_element("whats_required");
	$form_elements->create_element("file_upload");
	$form_elements->create_element("submit");
        ***/
	
	?>
	<script type="text/javascript">
		
		$(document).ready(function() {
			
			/*$("#press_advertisement_div").hide();
			$("#flyer_width_div").hide();
			$("#flyer_height_div").hide();
			$("#pos_width_div").hide();
			$("#pos_height_div").hide();*/
			
			$('#<?php echo $form_name ?>').validate({ // initialize the plugin
			
				rules: {
				
					first_name: {
						required: true,
						email: false
					},
					last_name: {
						required: true,
						minlength: 5
					},
					phone: {
						required: true,
						number: true
					},
					email: {
						required: true,
						email: true
					}
					
				}
				
			});
			
			
		});
		
	</script>
	<div style="padding:0px 0px 20px 0px;"></div>
</form>
<?php
include(INCLUDES_PATH . "/site_footer.php");
?>